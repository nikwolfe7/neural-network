package mlsp.cs.cmu.edu.dnn.training;

public interface DataInstanceGenerator {
  
  public DataInstance getNewDataInstance();

}
