function [J grad] = nnCostFunction(nn_params, ...
                                   input_layer_size, ...
                                   first_hidden_layer_size, ...
                                   second_hidden_layer_size, ...
                                   num_labels, ...
                                   X, y, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, num_labels, ...
%   X, y, lambda) computes the cost and gradient of the neural network. The
%   parameters for the neural network are "unrolled" into the vector
%   nn_params and need to be converted back into the weight matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices
% for our 2 layer neural network
t1 = (input_layer_size + 1) * first_hidden_layer_size;
t2 = (first_hidden_layer_size + 1) * second_hidden_layer_size;
t3 = (second_hidden_layer_size + 1) * num_labels;

Theta1 = reshape(nn_params(1:t1), first_hidden_layer_size, (input_layer_size + 1));
Theta2 = reshape(nn_params(t1+1:t1+t2), second_hidden_layer_size, (first_hidden_layer_size + 1));
Theta3 = reshape(nn_params(t1+t2+1:end), num_labels, (second_hidden_layer_size + 1));

% Setup some useful variables
m = size(X, 1);
         
% You need to return the following variables correctly 
J = 0;
Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));
Theta3_grad = zeros(size(Theta3));

% ====================== YOUR CODE HERE ======================
% Instructions: You should complete the code by working through the
%               following parts.
%
% Part 1: Feedforward the neural network and return the cost in the
%         variable J. After implementing Part 1, you can verify that your
%         cost function computation is correct by verifying the cost
%         computed in ex4.m
%

%================== M y  C o d e  P a r t  1 ==============================

% Add ones to the X data matrix
X = [ones(m, 1) X];

%disp(' size of X ')
%disp(size(X));

%disp(' size of y');
%disp(size(y));

yNN = y==1;
for i = 2:num_labels
    yNN = [yNN, y==i];
end;

%disp(' size of yNN');
%disp(size(yNN));

%disp(' size of Theta1 ')
%disp(size(Theta1));

%disp(' size of sigmoid(X * Theta1T');
%disp(size(sigmoid(X * Theta1')));

A2 = sigmoid(X * Theta1');
A21 = [ones(m, 1) A2];

B2 = sigmoid(A21 * Theta2');
B21 = [ones(m, 1), B2];

%disp(' size of A21');
%disp(size(A21));

%disp(' size of Theta2 ')
%disp(size(Theta2));

H_theta = sigmoid(B21 * Theta3');
%disp(' size of H_theta ');
%disp(size(H_theta));

J_theta = -(yNN .* log(H_theta)) - ((1 - yNN) .* log(1 - H_theta));
%disp(' size of J_theta');
%disp(size(J_theta));

J = (sum(sum(J_theta))/m) + (lambda/(2*m) * (sum(sum(Theta1(:,2:end).^2)) + sum(sum(Theta2(:,2:end).^2)) + sum(sum(Theta3(:,2:end).^2))));
%disp(' Cost J ');
%disp(J);

%pause;


%================== E n d  M y  C o d e  P a r t  1 =======================

% Part 2: Implement the backpropagation algorithm to compute the gradients
%         Theta1_grad and Theta2_grad. You should return the partial derivatives of
%         the cost function with respect to Theta1 and Theta2 in Theta1_grad and
%         Theta2_grad, respectively. After implementing Part 2, you can check
%         that your implementation is correct by running checkNNGradients
%
%         Note: The vector y passed into the function is a vector of labels
%               containing values from 1..K. You need to map this vector into a 
%               binary vector of 1's and 0's to be used with the neural network
%               cost function.
%
%         Hint: We recommend implementing backpropagation using a for-loop
%               over the training examples if you are implementing it for the 
%               first time.
%
%================== M y  C o d e  P a r t  2 ==============================

%disp(' size of X(1,:) ')
%disp(size(X(1,:)));

%disp(' size of yNN(t,:)');
%disp(size(yNN(1,:)));

%disp(' size of Theta1 ')
%disp(size(Theta1));

%disp(' size of a2 ');
%disp(size(X(1,:) * Theta1'));

%temp = X(1,:) * Theta1';
%temp = [ones(1, 1) temp];

%disp(' size of a2_1');
%disp(size(temp));

%disp(' size of Theta2 ')
%disp(size(Theta2));

%disp('size of a3 and z3');
%disp(size(temp * Theta2'));

%pause;

D1 = 0;
D2 = 0;
D3 = 0;
for t = 1:m
    a1 = X(t,:);
    yt = yNN(t,:);
    
    z2 = a1 * Theta1';
    a2 = sigmoid(z2);
    a2_1 = [ones(1, 1) a2];
    
    z3 = a2_1 *  Theta2';
    a3 = sigmoid(z3);
    a3_1 = [ones(1, 1) a3];
    
    z4 = a3_1 * Theta3';
    a4 = sigmoid(z4);
    
    delta4 = (a4 - yt);
    
    %disp(' size of delta3 ');
    %disp(size(delta3));
    
    %disp(' size of z2 ');
    %disp(size(z2));
    
    delta3 = delta4 * Theta3;
    delta3 = delta3(:,2:end) .* sigmoidGradient(z3);
    
    delta2 = delta3 * Theta2;
    delta2 = delta2(:,2:end) .* sigmoidGradient(z2);
    
    %disp(' size of delta2 ');
    %disp(size(delta2));
    
    %disp(' size of D1 ');
    %disp(size(delta2' * a1));
    
    %disp(' size of D2 ');
    %disp(size(delta3' * a2_1));
    
    %pause;
    
    D1 = D1 + delta2' * a1;
    D2 = D2 + delta3' * a2_1;  
    D3 = D3 + delta4' * a3_1;

end;

Theta1_grad = (1/m) * D1;
Theta2_grad = (1/m) * D2;
Theta3_grad = (1/m) * D3;

%disp(' size of Theta1_grad ');
%disp(size(Theta1_grad));

%disp(' size of Theta2_grad ');
%disp(size(Theta2_grad));

%pause;

%disp(' Value of D1 ');
%disp(D1);

%disp(' Value of D2 ');
%disp(D2);

%pause;
%================== E n d  M y  C o d e  P a r t  2 =======================
% Part 3: Implement regularization with the cost function and gradients.
%
%         Hint: You can implement this around the code for
%               backpropagation. That is, you can compute the gradients for
%               the regularization separately and then add them to Theta1_grad
%               and Theta2_grad from Part 2.
%

%================== M y  C o d e  P a r t  3 ==============================
%disp(' size of Theta1(:,2:end) ');
%disp(size(Theta1(:,2:end)));

%disp(' size of Theta2(:,2:end) ');
%disp(size(Theta2(:,2:end)));

%disp(' size of zeros(hidden_layer_size,1) ');
%disp(size(zeros(hidden_layer_size,1)));

%disp(' size of zeros(num_labels,1) ');
%disp(size(zeros(num_labels,1)));

Theta1_reg = (lambda/m) * [zeros(first_hidden_layer_size,1)  Theta1(:,2:end)];
Theta2_reg = (lambda/m) * [zeros(second_hidden_layer_size,1) Theta2(:,2:end)];
Theta3_reg = (lambda/m) * [zeros(num_labels,1)  Theta3(:,2:end)];

%disp(' size of Theta1_reg ');
%disp(size(Theta1_reg));

%disp(' szie of Theta2_reg ');
%disp(size(Theta2_reg));

%pause;

Theta1_grad = Theta1_grad + Theta1_reg;
Theta2_grad = Theta2_grad + Theta2_reg;
Theta3_grad = Theta3_grad + Theta3_reg;

%================== E n d  M y  C o d e  P a r t  3 =======================
















% -------------------------------------------------------------

% =========================================================================

% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:) ; Theta3_grad(:)];


end
